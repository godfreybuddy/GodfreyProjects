/**
 * repetition.h 
 *
 * author: Michael Mederos
 */

#ifndef REPETITION
    #define REPETITION
     
    /*function declarations*/
    
    int compare( const void* a, const void* b);
    void reps(double arr[], double size);
 
#endif
